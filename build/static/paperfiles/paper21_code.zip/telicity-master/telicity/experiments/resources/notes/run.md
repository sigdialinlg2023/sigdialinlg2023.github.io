### Run experiments for EN
```bash
python -m telicity.experiments.experiment_lr -cn lr_en -ip $DATA/multilingual_telicity -ip2 $CODE/telicity/telicity/experiments/resources/data/cross_lingual -ef mono_lingual/experiment_lr_en.csv -op $DATA/multilingual_telicity/_results/lr_en -obs file -lp $LOGS
```

### Run experiments for DE
```bash
python -m telicity.experiments.experiment_lr -cn lr_de -ip $DATA/multilingual_telicity -ip2 $CODE/telicity/telicity/experiments/resources/data/cross_lingual -ef mono_lingual/experiment_lr_de.csv -op $DATA/multilingual_telicity/_results/lr_de -obs file -lp $LOGS
```

### Run experiments for AR
```bash
python -m telicity.experiments.experiment_lr -cn lr_ar -ip $DATA/multilingual_telicity -ip2 $CODE -ef mono_lingual/experiment_lr_ar.csv -op $DATA/multilingual_telicity/_results/lr_ar -obs file -lp $LOGS
```

### Run experiments for all
```bash
python -m telicity.experiments.experiment_lr -cn lr_all -ip $DATA/multilingual_telicity -ip2 $CODE/telicity/ -ef mono_lingual/experiment_lr_ar_de_fa_ru_zh.csv -op $DATA/multilingual_telicity/_results/lr_all -obs file -lp $LOGS
```

### Run cross-lingual experiments for DE/EN & EN/DE
```bash
python -m telicity.experiments.experiment_lr_cross_lingual -cn lr_cross_lingual_en_de -ip $DATA/multilingual_telicity/cross_lingual_experiments -ef cross_lingual/experiment_lr_en_de.csv -op $DATA/multilingual_telicity/_results/lr_cross_lingual_en_de -obs file -lp $LOGS
```

### Run cross-lingual experiments for AR/DE & DE/AR
```bash
python -m telicity.experiments.experiment_lr_cross_lingual -cn lr_cross_lingual_ar_de -ip $DATA/multilingual_telicity/cross_lingual_experiments -ef cross_lingual/experiment_lr_ar_de_wikipedia.csv -op $DATA/multilingual_telicity/_results/lr_cross_lingual_ar_de -obs file -lp $LOGS
```

### Run cross-lingual experiments for all languages
```bash
python -m telicity.experiments.experiment_lr_cross_lingual -cn lr_cross_lingual_all -ip $DATA/multilingual_telicity/cross_lingual_experiments -ef cross_lingual/experiment_lr_all_wikipedia.csv -op $DATA/multilingual_telicity/_results/lr_cross_lingual_all -obs file -lp $LOGS
```

### Run cross-domain experiments for all languages
```bash
python -m telicity.experiments.experiment_lr_cross_domain -ip $CODE/telicity/arabic_data/ -op $DATA/telicity/_results/cross_domain -ef cross_domain/experiment_lr_ar.csv -cn cross_domain_ar -obs file -ll DEBUG
```

### Preprocess Cross-Lingual Setup
```bash
python -m telicity.corpora.preprocess -a prepare_cross_lingual_telicity_setup -ef prepare_cross_lingual_telicity_setup.csv -op $DATA/multilingual_telicity/cross_lingual_experiments -ip $DATA/multilingual_telicity -ip2 $CODE/telicity/telicity/experiments/resources/data/cross_lingual 
```