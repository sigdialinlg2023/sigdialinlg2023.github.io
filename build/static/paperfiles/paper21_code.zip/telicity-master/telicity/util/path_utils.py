__author__ = 'thk22'
from datetime import datetime
import os


PROJECT_PATH = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))) # Unwrap, unwrap, unwrap...


# incl timestamp: format='%d%m%Y_%H%M%S'
def timestamped_foldername(format='%d%m%Y'):
	return datetime.now().strftime(format)