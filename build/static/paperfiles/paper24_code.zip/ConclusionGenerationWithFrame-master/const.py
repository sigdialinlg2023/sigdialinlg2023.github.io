ISSUE_SPECIFIC_FRAME_START_TOKEN = "[Fis]"
ISSUE_SPECIFIC_FRAME_END_TOKEN = "[/Fis]"
GENERIC_MAPPED_FRAME_START_TOKEN = "[Fgm]"
GENERIC_MAPPED_FRAME_END_TOKEN = "[/Fgm]"
GENERIC_INFERRED_FRAME_START_TOKEN = "[Fgi]"
GENERIC_INFERRED_FRAME_END_TOKEN = "[/Fgi]"
TOPIC_START_TOKEN = "[T]"
TOPIC_END_TOKEN = "[/T]"
AVAILABLE_SCORES = ["bertscore", "bertscorePremCon", "framescore", "GRUEN", "rouge", "stancescore", "LengthScore",
                    "ClaimLikeScore", "frameissuespecificscore"]
