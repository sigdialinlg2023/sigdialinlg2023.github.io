# Zero-shot intent classification 
Train script, model multiplies cls tokens:
```
python scripts/train_baseline_multiply.py \
--model-name-or-path bert_path \
--tokenizer-path bert_path \
--data-folder data/split_0/ \
--data-meta data/meta/ \
--batch-size 200 \
--number-of-epochs 20 \
--train \
--test \
--save-path checkpoint.pt \
--save-test-metrics-file result_check.json
```

bash script: run experiment with/ without concept/action prediction, metric learning

```bash
bash bin/multipy_exp.sh
```
