{
 'o Marine Traffic': 'o site',
 'o Brasil': 'o país'
}