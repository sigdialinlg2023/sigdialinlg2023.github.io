from metodos_auxiliares_news import HelperClassNews

# instancia o objeto
objeto_publicacao = HelperClassNews()
      
# publicação
objeto_publicacao.publica_conteudo()