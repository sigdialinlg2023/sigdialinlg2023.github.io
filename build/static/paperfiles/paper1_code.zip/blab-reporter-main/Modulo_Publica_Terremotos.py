from metodos_auxiliares_terremotos import TerremotosClass

# instancia o objeto
objeto_publicacao = TerremotosClass()

# publicação
objeto_publicacao.publica_conteudo()