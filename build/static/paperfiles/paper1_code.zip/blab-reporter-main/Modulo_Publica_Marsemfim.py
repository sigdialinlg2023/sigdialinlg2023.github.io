from metodos_auxiliares_marsemfim import HelperClassMarsemfim

# instancia o objeto
objeto_publicacao = HelperClassMarsemfim()

# publicação
objeto_publicacao.publica_conteudo()