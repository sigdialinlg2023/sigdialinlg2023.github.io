from metodos_auxiliares_imagens import ImagensClass

# instancia o objeto
objeto_publicacao = ImagensClass()

# publicação
objeto_publicacao.publica_conteudo()