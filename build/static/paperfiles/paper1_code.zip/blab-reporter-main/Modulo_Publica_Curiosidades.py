from metodos_auxiliares_curiosidades import CuriosidadesClass

# instancia o objeto
objeto_publicacao = CuriosidadesClass()

# publicação
objeto_publicacao.publica_conteudo()