from metodos_auxiliares_tempo import HelperClassTempo

# classe auxiliar
objeto_publicacao = HelperClassTempo()

# gera resultados
objeto_publicacao.publica_conteudo()