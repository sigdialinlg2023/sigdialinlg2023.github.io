export LC_ALL=$(locale -a | grep UTF-8)
pip3 install nltk
python3 setup_nltk.py
