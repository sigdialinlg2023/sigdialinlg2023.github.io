# Supplementary Materials
## Software

The supplementary software files are the following:
-  **testrun_captioning.py**
	- Modified version of the file **oscar/run_captioning.py** originially provided in the [OSCAR github](https://github.com/microsoft/Oscar)
	- Use tag `--evaluate_during_training` together with tag `--val_yaml path/to/val.yaml ` to output validation loss and accuracy during training on validation dataset specified in `val.yaml`
	- Use tag `--save_steps n` to save model checkpoint every *n* epochs