# Use like 
# $>source prepare_path.sh
export PYTHONPATH=.:$PYTHONPATH
